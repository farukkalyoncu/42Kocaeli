/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fkalyonc <kalyoncufaruk123@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 22:43:36 by fkalyonc          #+#    #+#             */
/*   Updated: 2025/02/19 23:14:31 by fkalyonc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void	ft_putchar(char c)
{
	write(1, &c, 1);
}
int		main(void)
{
	ft_putchar('f');
    return(0);
}
/*
    unistd.h = write fonksiyonu kullanmak için gerekli kütüphane
    
    void = dönüş değeri olmayan fonksiyon tipi
    
    char = Tek karakter alıcağını ifade eder
    
    write ilk parametre= tanımlı ekranı ifade eder yani 1 olursa 1 numaralı tanımlı ekran yani terminal veya ekrana işarettir
    
    write ikinci  parametre= & işareti değişkenin bellek adresini alır , write fonksiyonu karakteri değil karakterin bellekteki yerini alır
    &c ifade c karakterinin adresini (pointer) temsil eder. write fonksiyonu bir pointer alacağı için & operatörü kullanarak c nin adresi alınır

    write üçüncü  parametre = kaç bytlık veri çıktısı olucak o yazılır 1 yazmak 1 baytlık değer

    main = C dilinin başlama noktasınıdır genellikle int değer döndüğü için int ile başlar 

    main(void) = void bir parametresiz olduğunu herhangi bir parametre almıycağını belirtir
*/