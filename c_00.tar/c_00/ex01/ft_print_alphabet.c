/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fkalyonc <kalyoncufaruk123@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 23:24:09 by fkalyonc          #+#    #+#             */
/*   Updated: 2025/02/19 23:29:06 by fkalyonc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# include <unistd.h>
void ekranayaz(char a)
{
    write(1, &a, 1);
}
void ft_print_alphabet(void)
{
    char alfabe;
    alfabe='a';
    while (alfabe<='z')
    {
        ekranayaz(alfabe);
        alfabe++;
    }
    ekranayaz('\n');
}
int main(void)
{
    ft_print_alphabet();
    return(0);
}