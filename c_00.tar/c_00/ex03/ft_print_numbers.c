/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_numbers.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fkalyonc <kalyoncufaruk123@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 23:37:48 by fkalyonc          #+#    #+#             */
/*   Updated: 2025/02/19 23:52:10 by fkalyonc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ekranayaz(char f)
{
    write(1,&f,1);
}
void ft_print_numbers(void)
{
    int sayilar=0;
    while (sayilar<=9)
    {
        ekranayaz(sayilar+'0');// ekrana yazdırabilmek için ascıı karşılık lazım buda karakter formatında olur
        sayilar++;
    }
}
int main(void)
{
    ft_print_numbers();
    return (0);
}