/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_reverse_alphabet.c                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fkalyonc <kalyoncufaruk123@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/19 23:31:02 by fkalyonc          #+#    #+#             */
/*   Updated: 2025/02/19 23:35:47 by fkalyonc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
void ekranayaz(char f)
{
    write(1,&f,1);
}
void ft_print_reverse_alphabet(void)
{
    char alfabe='z';
    while (alfabe>='a')
    {
        ekranayaz(alfabe);
        alfabe--;
    }
    ekranayaz('\n');
}
int main(void)
{
    ft_print_reverse_alphabet();
}