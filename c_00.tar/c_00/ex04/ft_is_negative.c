/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fkalyonc <kalyoncufaruk123@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/20 00:06:13 by fkalyonc          #+#    #+#             */
/*   Updated: 2025/02/20 00:13:06 by fkalyonc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
/*void ekranayaz(char f)
{
    write(1,&f,1);
}*/
void ft_is_negative(int n)
{
    if(n<0)
    {
        write(1,"N",1);
    }
    else
    {
        write(1,"P",1);
    }
    write(1,"\n",1);
}
int main(void)
{
    ft_is_negative(15);
    ft_is_negative(-1);
    ft_is_negative(0);
}